import asyncio
import websockets
import json
import hashlib
import base64

# Global dictionaries to keep track of connected clients and neighbourhood servers
connected_clients = {}
neighbourhood_servers = {}

# Generate the fingerprint (Base64Encode(SHA-256(exported RSA public key)))
def generate_fingerprint(public_key_pem):
    fingerprint = base64.b64encode(hashlib.sha256(public_key_pem.encode('utf-8')).digest()).decode('utf-8')
    return fingerprint

# Step 1: Handle the "hello" message
async def handle_hello_message(websocket, data):
    username = data.get("username")
    public_key_pem = data.get("public_key")
    
    # Generate the fingerprint for this user
    fingerprint = generate_fingerprint(public_key_pem)

    # Store the client's information
    connected_clients[fingerprint] = {
        "username": username,
        "websocket": websocket,
        "public_key": public_key_pem
    }

    print(f"User {username} with fingerprint {fingerprint} connected.")

    # Step 2: Acknowledge the hello message
    hello_ack_message = {
        "data": {
            "type": "hello_ack",
            "message": f"Hello {username}, you are connected to the server!"
        }
    }
    await websocket.send(json.dumps(hello_ack_message))

    # Step 3: Send the list of connected clients to the new client
    await send_client_list(websocket)

    # Step 4: Broadcast the updated client list to other servers
    await broadcast_client_list()

# Step 2: Send the list of currently connected clients to a client
async def send_client_list(websocket):
    client_list = []
    for fingerprint, client_info in connected_clients.items():
        client_list.append({
            "username": client_info["username"],
            "fingerprint": fingerprint
        })
    
    client_list_message = {
        "data": {
            "type": "client_list",
            "clients": client_list
        }
    }
    await websocket.send(json.dumps(client_list_message))
    print("Sent client list to the new client.")

# Step 3: Broadcast the client list to all neighbourhood servers
async def broadcast_client_list():
    client_list = []
    for fingerprint, client_info in connected_clients.items():
        client_list.append({
            "username": client_info["username"],
            "fingerprint": fingerprint
        })

    broadcast_message = {
        "data": {
            "type": "client_list",
            "clients": client_list
        }
    }
    for server_websocket in neighbourhood_servers.values():
        await server_websocket.send(json.dumps(broadcast_message))
    print("Broadcasted client list to neighbourhood servers.")

# Step 4: Handle chat messages
async def handle_chat_message(websocket, data):
    destination_fingerprints = data.get("destination_servers")
    message = data.get("message")

    for fingerprint in destination_fingerprints:
        if fingerprint in connected_clients:
            destination_websocket = connected_clients[fingerprint]["websocket"]
            sender = next((fp for fp, client in connected_clients.items() if client['websocket'] == websocket), None)
            chat_message = {
                "data": {
                    "type": "chat_message",
                    "sender": connected_clients[sender]['username'],
                    "message": message
                }
            }
            await destination_websocket.send(json.dumps(chat_message))
            print(f"Message sent from {connected_clients[sender]['username']} to {connected_clients[fingerprint]['username']}")
        else:
            # Forward the message to other servers if the client is not found locally
            await forward_message_to_neighbourhood(fingerprint, message, websocket)

# Step 5: Forward chat messages to other servers
async def forward_message_to_neighbourhood(fingerprint, message, websocket):
    sender = next((fp for fp, client in connected_clients.items() if client['websocket'] == websocket), None)
    forward_message = {
        "data": {
            "type": "chat_message",
            "sender": connected_clients[sender]['username'],
            "message": message,
            "destination_fingerprint": fingerprint
        }
    }
    for server_websocket in neighbourhood_servers.values():
        await server_websocket.send(json.dumps(forward_message))
    print(f"Forwarded message to neighbourhood for client {fingerprint}")

# Step 6: Handle incoming messages
async def handle_incoming_message(websocket, message):
    data = message.get("data", {})
    message_type = data.get("type")

    if message_type == "hello":
        await handle_hello_message(websocket, data)
    elif message_type == "chat_message":
        await handle_chat_message(websocket, data)
    elif message_type == "client_list":
        await update_client_list_from_neighbourhood(data)

# Step 7: Handle connections from other servers (neighbourhood)
async def handle_neighbourhood_connection(websocket, path):
    try:
        async for message in websocket:
            await handle_incoming_message(websocket, json.loads(message))
    except websockets.ConnectionClosed:
        print(f"Neighbourhood server disconnected.")

# Step 8: Update client list from neighbourhood
async def update_client_list_from_neighbourhood(data):
    for client in data.get("clients", []):
        fingerprint = client["fingerprint"]
        if fingerprint not in connected_clients:
            connected_clients[fingerprint] = {
                "username": client["username"],
                "websocket": None  # No local websocket for remote clients
            }
    print("Updated client list from neighbourhood.")

# Step 9: Connect to other servers in the neighbourhood
async def connect_to_neighbourhood(server_url):
    async with websockets.connect(server_url) as websocket:
        neighbourhood_servers[server_url] = websocket
        print(f"Connected to neighbourhood server: {server_url}")
        await listen_to_neighbourhood(websocket)

# Step 10: Listen for messages from other servers
async def listen_to_neighbourhood(websocket):
    try:
        async for message in websocket:
            await handle_incoming_message(websocket, json.loads(message))
    except websockets.ConnectionClosed:
        print(f"Disconnected from neighbourhood server.")

# Step 11: Handle a connected client
async def handle_client(websocket, path):
    try:
        async for message in websocket:
            await handle_incoming_message(websocket, json.loads(message))
    except websockets.ConnectionClosed:
        # Handle client disconnection
        disconnected_client = None
        for fingerprint, client_info in connected_clients.items():
            if client_info["websocket"] == websocket:
                disconnected_client = fingerprint
                break
        
        if disconnected_client:
            del connected_clients[disconnected_client]
            print(f"Client with fingerprint {disconnected_client} disconnected.")
            await broadcast_client_list()

# Step 12: Start the WebSocket server and connect to neighbourhood
async def start_server():
    # Start the WebSocket server for clients
    server = await websockets.serve(handle_client, "localhost", 12345)
    print("Server started on ws://localhost:12345")

    # Connect to other servers in the neighbourhood (if applicable)
    try:
        await connect_to_neighbourhood("ws://localhost:12346")  # Change this if needed
    except Exception as e:
        print(f"Could not connect to neighbourhood server: {e}")

    await server.wait_closed()

# Entry point
if __name__ == "__main__":
    asyncio.run(start_server())
