import asyncio
import websockets
import json

# Client public/private key (for simplicity, hardcoded; in a real implementation, this would be generated)
PUBLIC_KEY_PEM = """
-----BEGIN PUBLIC KEY-----
...
-----END PUBLIC KEY-----
"""

USERNAME = "user_a"  # Change this for each client

# Step 1: Send the hello message to the server
async def send_hello_message(websocket):
    hello_message = {
        "data": {
            "type": "hello",
            "username": USERNAME,
            "public_key": PUBLIC_KEY_PEM
        }
    }
    await websocket.send(json.dumps(hello_message))
    print("Hello message sent.")

# Step 2: Handle incoming messages from the server
async def handle_incoming_message(websocket, message):
    data = message.get("data", {})
    message_type = data.get("type")

    if message_type == "hello_ack":
        print(data.get("message"))
    elif message_type == "client_list":
        await handle_client_list(data)
    elif message_type == "chat_message":
        await handle_chat_message(data)

# Step 3: Handle receiving the client list
connected_clients = {}

async def handle_client_list(data):
    global connected_clients
    clients = data.get("clients", [])
    connected_clients = {client["fingerprint"]: client["username"] for client in clients}
    print("Received client list:")
    for fingerprint, username in connected_clients.items():
        print(f"Username: {username}, Fingerprint: {fingerprint}")

# Step 4: Handle chat messages
async def handle_chat_message(data):
    sender = data.get("sender")
    message = data.get("message")
    print(f"Message from {sender}: {message}")

# Step 5: Send a chat message to a specified fingerprint
async def send_chat_message(websocket, destination_fingerprints, message):
    chat_message = {
        "data": {
            "type": "chat_message",
            "destination_servers": destination_fingerprints,
            "message": message
        }
    }
    await websocket.send(json.dumps(chat_message))
    print("Chat message sent.")

# Step 6: Connect to the WebSocket server and run the client
async def connect_to_server():
    uri = "ws://localhost:12345"  # Change this to the correct server URL
    async with websockets.connect(uri) as websocket:
        await send_hello_message(websocket)

        # Step 7: Listen for incoming messages
        async for message in websocket:
            await handle_incoming_message(websocket, json.loads(message))

            # Step 8: Prompt to send a public message
            if connected_clients:  # Ensure there are clients to send messages to
                send_message = input("Send a public message? (yes/no): ")
                if send_message.lower() == "yes":
                    public_message = input("Enter the public message: ")
                    await send_chat_message(websocket, list(connected_clients.keys()), public_message)

# Entry point
if __name__ == "__main__":
    asyncio.run(connect_to_server())
